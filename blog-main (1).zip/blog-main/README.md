# Blogs in Xguguguの 小站

地址：https://xgugugu.github.io/blog

本站的诞生离不开以下开源项目：
- [jQuery](https://jquery.com/)
- [marked](https://github.com/markedjs/marked)
- [highlight.js](https://highlightjs.org/)
- [Semantic UI](https://semantic-ui.com/)

基于 [MIT License](https://github.com/xgugugu/blog/blob/main/LICENSE) 开源
